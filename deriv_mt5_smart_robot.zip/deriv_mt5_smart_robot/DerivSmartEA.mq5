//+------------------------------------------------------------------+
//| DerivSmartEA.mq5                                                 |
//| Demo-first example EA: EMA trend + RSI confirmation + ATR exits. |
//| This is a starter strategy, not a validated profitable system.   |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "Demo-only MT5 EA starter with risk controls and NO TRADE filters."

#include <Trade/Trade.mqh>
CTrade trade;

input bool   EnableDemoExecution = false;   // Keep false until backtesting is complete
input ulong  MagicNumber = 26100901;
input ENUM_TIMEFRAMES SignalTimeframe = PERIOD_M15;
input int    FastEMA = 20;
input int    SlowEMA = 50;
input int    RSIPeriod = 14;
input int    ATRPeriod = 14;
input double RiskPercent = 0.25;            // % equity risked per trade
input double StopATRMultiplier = 2.0;
input double RewardRiskRatio = 1.5;
input int    MaxSpreadPoints = 100;         // Tune separately for each symbol
input double MaxDailyLossPercent = 2.0;     // EA locks new entries after this loss
input bool   OnePositionPerSymbol = true;
input bool   AllowBuy = true;
input bool   AllowSell = true;

int hFast = INVALID_HANDLE, hSlow = INVALID_HANDLE, hRSI = INVALID_HANDLE, hATR = INVALID_HANDLE;
datetime lastBarTime = 0;
int dayKey = -1;
double dayStartEquity = 0.0;
bool dailyLocked = false;

// Only intended to run on demo accounts. Broker/account flags vary, so fail closed if not demo.
bool IsDemoAccount()
{
   return (AccountInfoInteger(ACCOUNT_TRADE_MODE) == ACCOUNT_TRADE_MODE_DEMO);
}

int CurrentDayKey()
{
   MqlDateTime t;
   TimeToStruct(TimeCurrent(), t);
   return t.year * 1000 + t.day_of_year;
}

bool IsNewBar()
{
   datetime t[2];
   ArraySetAsSeries(t, true);
   if(CopyTime(_Symbol, SignalTimeframe, 0, 2, t) != 2) return false;
   if(t[0] == lastBarTime) return false;
   lastBarTime = t[0];
   return true;
}

bool HasOurPosition()
{
   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) == _Symbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC) == MagicNumber)
         return true;
   }
   return false;
}

double NormalizeVolume(double lots)
{
   double vmin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double vmax = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(step <= 0) return 0.0;
   lots = MathFloor(lots / step) * step;
   lots = MathMax(vmin, MathMin(vmax, lots));
   int digits = 0;
   double tmp = step;
   while(digits < 8 && MathAbs(tmp - MathRound(tmp)) > 1e-8) { tmp *= 10.0; digits++; }
   return NormalizeDouble(lots, digits);
}

double LotsForRisk(double stopDistancePrice)
{
   if(stopDistancePrice <= 0.0) return 0.0;
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double riskMoney = equity * RiskPercent / 100.0;
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE_LOSS);
   if(tickValue <= 0.0) tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || riskMoney <= 0.0) return 0.0;
   double lossPerLot = (stopDistancePrice / tickSize) * tickValue;
   if(lossPerLot <= 0.0) return 0.0;
   double lots = NormalizeVolume(riskMoney / lossPerLot);
   // Do not force minimum volume if it exceeds intended risk.
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   if(lots < minLot) return 0.0;
   return lots;
}

int OnInit()
{
   if(!IsDemoAccount())
   {
      Print("SAFETY BLOCK: DerivSmartEA is demo-only and will not run on a non-demo account.");
      return INIT_FAILED;
   }
   if(RiskPercent <= 0 || RiskPercent > 1.0)
   {
      Print("Safety block: RiskPercent must be greater than 0 and no more than 1.0% for this starter.");
      return INIT_PARAMETERS_INCORRECT;
   }
   hFast = iMA(_Symbol, SignalTimeframe, FastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlow = iMA(_Symbol, SignalTimeframe, SlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   hRSI = iRSI(_Symbol, SignalTimeframe, RSIPeriod, PRICE_CLOSE);
   hATR = iATR(_Symbol, SignalTimeframe, ATRPeriod);
   if(hFast == INVALID_HANDLE || hSlow == INVALID_HANDLE || hRSI == INVALID_HANDLE || hATR == INVALID_HANDLE)
   {
      Print("Could not initialize indicator handles.");
      return INIT_FAILED;
   }
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetTypeFillingBySymbol(_Symbol);
   dayKey = CurrentDayKey();
   dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   Print("Initialized in demo-only mode. EnableDemoExecution=", EnableDemoExecution);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hFast != INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow != INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRSI != INVALID_HANDLE) IndicatorRelease(hRSI);
   if(hATR != INVALID_HANDLE) IndicatorRelease(hATR);
}

void OnTick()
{
   if(!IsDemoAccount()) return; // fail closed if account mode changes
   int today = CurrentDayKey();
   if(today != dayKey)
   {
      dayKey = today;
      dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
      dailyLocked = false;
   }
   if(dayStartEquity > 0 && AccountInfoDouble(ACCOUNT_EQUITY) <= dayStartEquity * (1.0 - MaxDailyLossPercent / 100.0))
   {
      dailyLocked = true;
      Print("DAILY LOSS LOCK: new entries blocked.");
   }
   if(!IsNewBar()) return;
   if(!EnableDemoExecution || dailyLocked) return;

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick)) return;
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   if(point <= 0) return;
   double spreadPoints = (tick.ask - tick.bid) / point;
   if(spreadPoints > MaxSpreadPoints)
   {
      Print("NO TRADE: spread filter. spread points=", spreadPoints);
      return;
   }
   if(OnePositionPerSymbol && HasOurPosition()) return;

   double fast[3], slow[3], rsi[3], atr[3], close[3];
   ArraySetAsSeries(fast, true); ArraySetAsSeries(slow, true);
   ArraySetAsSeries(rsi, true); ArraySetAsSeries(atr, true); ArraySetAsSeries(close, true);
   if(CopyBuffer(hFast, 0, 0, 3, fast) != 3 ||
      CopyBuffer(hSlow, 0, 0, 3, slow) != 3 ||
      CopyBuffer(hRSI, 0, 0, 3, rsi) != 3 ||
      CopyBuffer(hATR, 0, 0, 3, atr) != 3 ||
      CopyClose(_Symbol, SignalTimeframe, 0, 3, close) != 3)
   {
      Print("NO TRADE: indicator data unavailable.");
      return;
   }

   // Use index 1: most recently completed candle.
   bool buy = AllowBuy && fast[1] > slow[1] && close[1] > fast[1] && rsi[1] >= 52 && rsi[1] <= 68;
   bool sell = AllowSell && fast[1] < slow[1] && close[1] < fast[1] && rsi[1] >= 32 && rsi[1] <= 48;
   if(buy == sell)
   {
      Print("NO TRADE: conditions are not aligned.");
      return;
   }
   if(atr[1] <= 0)
   {
      Print("NO TRADE: ATR unavailable.");
      return;
   }

   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   double stopDistance = atr[1] * StopATRMultiplier;
   double lots = LotsForRisk(stopDistance);
   if(lots <= 0)
   {
      Print("NO TRADE: calculated lot size is invalid or below broker minimum.");
      return;
   }

   bool ok = false;
   if(buy)
   {
      double sl = NormalizeDouble(tick.ask - stopDistance, digits);
      double tp = NormalizeDouble(tick.ask + stopDistance * RewardRiskRatio, digits);
      ok = trade.Buy(lots, _Symbol, 0.0, sl, tp, "DerivSmartEA demo BUY");
   }
   else if(sell)
   {
      double sl = NormalizeDouble(tick.bid + stopDistance, digits);
      double tp = NormalizeDouble(tick.bid - stopDistance * RewardRiskRatio, digits);
      ok = trade.Sell(lots, _Symbol, 0.0, sl, tp, "DerivSmartEA demo SELL");
   }

   Print(ok ? "DEMO ORDER REQUEST ACCEPTED" : "ORDER FAILED",
         " | retcode=", trade.ResultRetcode(), " | ", trade.ResultRetcodeDescription(),
         " | lots=", lots, " | risk%=", RiskPercent);
}

void OnTradeTransaction(const MqlTradeTransaction& trans,
                        const MqlTradeRequest& request,
                        const MqlTradeResult& result)
{
   // Keep terminal journal as the audit trail for this starter.
}
