import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import MetaTrader5 as mt5
import pandas as pd
from signal_engine import analyze_symbol

TITLE = "Deriv MT5 Smart Robot — Analysis Panel (Execution disabled)"


class App:
    def __init__(self, root):
        self.root = root
        self.root.title(TITLE)
        self.root.geometry("960x720")
        self.root.minsize(800, 580)
        self.connected = False
        self.terminal = tk.StringVar()
        self.login = tk.StringVar()
        self.password = tk.StringVar()
        self.server = tk.StringVar()
        self.symbol = tk.StringVar(value="EURUSD")
        self.tf = tk.StringVar(value="M15")
        self.status = tk.StringVar(value="Disconnected — signal-only panel")
        self._ui()
        for path in [r"C:\Program Files\MetaTrader 5\terminal64.exe",
                     r"C:\Program Files (x86)\MetaTrader 5\terminal.exe"]:
            if os.path.exists(path):
                self.terminal.set(path)
                break

    def _ui(self):
        pad = {"padx": 7, "pady": 5}
        box = ttk.LabelFrame(self.root, text="Deriv MT5 Connection — credentials remain local")
        box.pack(fill="x", padx=12, pady=10)
        ttk.Label(box, text="Terminal executable").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(box, textvariable=self.terminal, width=65).grid(row=0, column=1, sticky="ew", **pad)
        ttk.Button(box, text="Browse", command=self.browse).grid(row=0, column=2, **pad)
        ttk.Label(box, text="Login number").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(box, textvariable=self.login, width=30).grid(row=1, column=1, sticky="w", **pad)
        ttk.Label(box, text="Password").grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(box, textvariable=self.password, show="*", width=30).grid(row=2, column=1, sticky="w", **pad)
        ttk.Label(box, text="Server (exact name)").grid(row=3, column=0, sticky="w", **pad)
        ttk.Entry(box, textvariable=self.server, width=45).grid(row=3, column=1, sticky="w", **pad)
        row = ttk.Frame(box)
        row.grid(row=4, column=1, sticky="w", **pad)
        ttk.Button(row, text="Connect", command=self.connect).pack(side="left", padx=(0, 6))
        ttk.Button(row, text="Disconnect", command=self.disconnect).pack(side="left")
        box.columnconfigure(1, weight=1)

        market = ttk.LabelFrame(self.root, text="Market Analysis")
        market.pack(fill="x", padx=12, pady=6)
        ttk.Label(market, text="Symbol").grid(row=0, column=0, **pad)
        ttk.Entry(market, textvariable=self.symbol, width=22).grid(row=0, column=1, **pad)
        ttk.Label(market, text="Timeframe").grid(row=0, column=2, **pad)
        ttk.Combobox(market, textvariable=self.tf, values=["M1","M5","M15","M30","H1","H4","D1"],
                     width=8, state="readonly").grid(row=0, column=3, **pad)
        ttk.Button(market, text="Analyze", command=self.analyze).grid(row=0, column=4, **pad)
        ttk.Button(market, text="Account Info", command=self.account).grid(row=0, column=5, **pad)

        ttk.Label(self.root, text="ORDER EXECUTION DISABLED IN THIS PYTHON PANEL. Use the MQL5 EA for demo-only execution after testing.",
                  foreground="#a11").pack(anchor="w", padx=16, pady=5)
        ttk.Label(self.root, textvariable=self.status).pack(anchor="w", padx=16)
        out = ttk.LabelFrame(self.root, text="Output")
        out.pack(fill="both", expand=True, padx=12, pady=8)
        self.log = tk.Text(out, wrap="word", font=("Consolas", 10))
        self.log.pack(fill="both", expand=True, padx=8, pady=8)
        self.write("Connect using a Deriv MT5 demo account. Enter the exact server name shown in MT5.")

    def write(self, s):
        self.log.insert("end", s + "\n")
        self.log.see("end")

    def browse(self):
        p = filedialog.askopenfilename(title="Select MT5 terminal executable",
            filetypes=[("MetaTrader terminal", "*.exe"), ("All files", "*.*")])
        if p:
            self.terminal.set(p)

    def connect(self):
        try:
            if not self.login.get().strip() or not self.password.get() or not self.server.get().strip():
                messagebox.showerror("Missing details", "Enter login, password, and exact server.")
                return
            try:
                login = int(self.login.get().strip())
            except ValueError:
                messagebox.showerror("Invalid login", "MT5 login must be numeric.")
                return
            kw = {"login": login, "password": self.password.get(), "server": self.server.get().strip(), "timeout": 15000}
            if self.terminal.get().strip():
                kw["path"] = self.terminal.get().strip()
            if not mt5.initialize(**kw):
                messagebox.showerror("Connection failed", f"MT5 error: {mt5.last_error()}")
                return
            info = mt5.account_info()
            if info is None:
                mt5.shutdown()
                messagebox.showerror("Account error", f"Account info unavailable: {mt5.last_error()}")
                return
            self.connected = True
            self.password.set("")
            self.status.set(f"Connected: {info.login} | {info.server} | Python order execution disabled")
            self.write(f"Connected. Login={info.login}; Server={info.server}; Currency={info.currency}; Balance={info.balance:.2f}; Equity={info.equity:.2f}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def disconnect(self):
        mt5.shutdown()
        self.connected = False
        self.status.set("Disconnected")
        self.write("Disconnected.")

    def account(self):
        if not self.connected:
            messagebox.showinfo("Not connected", "Connect first.")
            return
        a = mt5.account_info()
        if a:
            self.write(f"ACCOUNT | balance={a.balance:.2f} {a.currency} | equity={a.equity:.2f} | margin_free={a.margin_free:.2f}")
        else:
            self.write(f"Account query failed: {mt5.last_error()}")

    def analyze(self):
        if not self.connected:
            messagebox.showinfo("Not connected", "Connect first.")
            return
        symbol = self.symbol.get().strip()
        tfmap = {"M1":mt5.TIMEFRAME_M1, "M5":mt5.TIMEFRAME_M5, "M15":mt5.TIMEFRAME_M15,
                 "M30":mt5.TIMEFRAME_M30, "H1":mt5.TIMEFRAME_H1, "H4":mt5.TIMEFRAME_H4, "D1":mt5.TIMEFRAME_D1}
        if not mt5.symbol_select(symbol, True):
            messagebox.showerror("Symbol unavailable", "Check Market Watch for the exact broker symbol name.")
            return
        rates = mt5.copy_rates_from_pos(symbol, tfmap[self.tf.get()], 0, 250)
        if rates is None or len(rates) < 80:
            messagebox.showerror("Insufficient data", f"Could not retrieve enough candles: {mt5.last_error()}")
            return
        res = analyze_symbol(pd.DataFrame(rates))
        tick, inf = mt5.symbol_info_tick(symbol), mt5.symbol_info(symbol)
        self.write(f"\n{'='*54}\n{symbol} | {self.tf.get()} | Bid={tick.bid if tick else 'n/a'} Ask={tick.ask if tick else 'n/a'}")
        self.write(f"Signal: {res['signal']} | {res['reason']}")
        self.write(f"EMA20={res['ema20']:.6f} EMA50={res['ema50']:.6f} RSI14={res['rsi14']:.2f} | Candle UTC={res['bar_time']}")
        self.write("No order sent by this Python panel.")

    def close(self):
        try: mt5.shutdown()
        except Exception: pass
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
