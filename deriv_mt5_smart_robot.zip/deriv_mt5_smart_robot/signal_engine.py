import pandas as pd


def analyze_symbol(rates: pd.DataFrame) -> dict:
    """Example signal on completed candles only. Not a validated profitable strategy."""
    if len(rates) < 80:
        raise ValueError("At least 80 candles are required.")
    df = rates.iloc[:-1].copy()  # exclude current, still-forming candle
    close = df["close"].astype(float)
    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    ag = gain.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    al = loss.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    rs = ag / al.replace(0, float("nan"))
    rsi = 100 - 100 / (1 + rs)

    e20, e50 = float(ema20.iloc[-1]), float(ema50.iloc[-1])
    rv, last_close = float(rsi.iloc[-1]), float(close.iloc[-1])
    bar_time = pd.to_datetime(int(df["time"].iloc[-1]), unit="s", utc=True).isoformat()

    if pd.isna(rv):
        signal, reason = "NO TRADE", "RSI is unavailable."
    elif e20 > e50 and last_close > e20 and 52 <= rv <= 68:
        signal, reason = "BUY", "Bullish EMA alignment and RSI confirmation."
    elif e20 < e50 and last_close < e20 and 32 <= rv <= 48:
        signal, reason = "SELL", "Bearish EMA alignment and RSI confirmation."
    else:
        signal, reason = "NO TRADE", "Trend and momentum are not aligned."
    return {"signal": signal, "reason": reason, "ema20": e20, "ema50": e50,
            "rsi14": rv, "bar_time": bar_time}
