# Deriv MT5 Smart Robot — Demo-First

A Python desktop control panel and MQL5 Expert Advisor starter for Deriv MT5. The project is designed to analyze forex and Deriv synthetic indices, generate transparent signals, apply risk controls, and progress through testing before demo execution.

## Safety-first rollout
1. Connect and inspect account/symbols.
2. Generate signals only.
3. Backtest in MetaTrader 5 Strategy Tester.
4. Forward-test on a **Deriv demo account**.
5. Enable demo order execution only after reviewing the code and test results.
6. Keep live execution disabled unless separately reviewed and intentionally enabled.

This is starter software, not a validated profitable strategy. It does not guarantee profits.

## Project files
- `app.py`: local Windows desktop connection/account/symbol panel and signal analysis.
- `signal_engine.py`: example EMA/RSI signal logic with `NO TRADE` conditions.
- `DerivSmartEA.mq5`: MQL5 EA starter for MetaTrader 5 Strategy Tester/demo testing; has a demo-account gate, risk-based position sizing, stop-loss/take-profit, spread filter, daily loss lock, and configurable execution switch.
- `requirements.txt`: Python dependencies.
- `.gitignore`: avoids committing common local secrets and generated files.

## Python panel setup (Windows)
Prerequisites: Windows 10/11, Python 3.10/3.11 64-bit, and Deriv MT5 desktop terminal installed.

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Enter your MT5 login, password, and server locally in the application. The password field is cleared after successful connection. Do not commit credentials to GitHub.

## Install the EA in MT5
1. Open Deriv MT5.
2. Click **File → Open Data Folder**.
3. Open `MQL5\\Experts`.
4. Copy `DerivSmartEA.mq5` into that folder.
5. Open MetaEditor, open the file, and press **F7** to compile.
6. In MT5, open **View → Strategy Tester** and select `DerivSmartEA`.
7. Test on historical data first. Then attach it to a demo chart.
8. Keep `EnableDemoExecution = false` until you have reviewed backtests and understand the EA's behavior.
9. To permit demo execution, set `EnableDemoExecution = true` in EA inputs and verify the terminal is logged into a demo account. The EA has a hard demo-only account check and should refuse non-demo accounts.

## Broker symbols
Deriv symbol names vary by account and server. Examples such as `Volatility 75 Index` or `EURUSD` are not guaranteed. In Market Watch, use the exact symbol names provided by your Deriv account. Synthetic indices are not available on every account/server.

## Risk controls in the EA
- Default risk per trade: 0.25% of equity.
- Maximum spread filter (points): configurable; tune per symbol.
- One position per symbol/magic number.
- Daily equity-loss lock: configurable.
- Stop-loss and take-profit derived from ATR.
- No trade when signal conditions do not align.
- Demo-only account guard.

These are guardrails, not guarantees. The daily loss lock is based on the EA's observed day-start equity while it is running and is not a substitute for broker-side protection.

## Strategy
The example logic uses EMA 20/50 trend alignment, RSI confirmation, and ATR-based stop/target sizing on completed candles. It is deliberately simple and must be validated. Synthetic indices can behave differently from forex; test them separately and tune settings per symbol.

## GitHub security
Never commit MT5 passwords, account screenshots, investor passwords, or tokens. If a password has ever been exposed, change it. Keep execution disabled while developing.
